<div class="panel panel-info">
			<div class="panel-heading"><h5>Menus</h5></div>
			<div class="panel-body">
				<a href="Homer.php" class="btn btn-info btn-block">Home 
					<span class="fui-home"></span></a>
				<a href="php-db-template.php" class="btn btn-info btn-block">Simple Component Search 
					<span class="fui-search"></span></a>
				<a href="advance-search.php" class="btn btn-info btn-block">Advanced Component Search 
					<span class="fui-search"></span></a>
				<a href="insert-form.php" class="btn btn-info btn-block">Insert New Component 
					<span class="fui-plus"></span></a>
					<a href="register.php" class="btn btn-info btn-block">Register 
					<span class="fui-warning"></span></a>
				<a href="search-update-delete.php" class="btn btn-danger btn-block">Update/Delete Component 
					<span class="fui-calculator"></span></a>
					<a href="calculator.html" class="btn btn-info btn-block">Calculator
					<span class="fui-search"></span></a>
				<a href="logout.php" class="btn btn-info btn-block">Logout 
					<span class="fui-export"></span></a>
                
			</div>
		</div>