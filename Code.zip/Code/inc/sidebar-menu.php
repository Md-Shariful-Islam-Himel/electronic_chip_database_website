		<div class="panel panel-info">
			<div class="panel-heading"><h5>Menus</h5></div>
			<div class="panel-body">
				<a href="Home.php" class="btn btn-info btn-block">Home 
					<span class="fui-home"></span></a>
				<a href="php-db-template.php" class="btn btn-info btn-block">Simple Component Search 
					<span class="fui-search"></span></a>
					<a href="calculator.html" class="btn btn-info btn-block">Calculator 
					<span class="fui-warning"></span></a>
				<a href="login.php" class="btn btn-info btn-block" target="_blank">Login
				<span class="fui-export"></span></a>
				</a>
			</div>
		</div>