
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
          </button>
          <a class="navbar-brand" href="http://localhost/myhr/home.php" target="_blank">Electronic Component Database for lab</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            
      </div>
    </div>
	</div><!-- end nav-bar-inverse -->