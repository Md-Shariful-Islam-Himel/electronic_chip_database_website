      <div class="bottom-menu bottom-menu-inverse">
          
            <div class="col-md-22 col-sm-2">
              <a href="http://localhost/myhr/home.php" target="new" class="bottom-menu-brand">Electronic Component Database for lab</a>
            </div>
            <div class="col-md-8 col-sm-8" position="right">
              <div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3" position="right">
		<div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div><script>(function () {
        var setting = {"height":276,"width":605,"zoom":14,"queryString":"Shahjalal University of Science and Technology, University Avenue, Sylhet, Bangladesh","place_id":"ChIJq04UAmBVUDcRq_KpvE3hd-I","satellite":false,"centerCoord":[24.917223657377182,91.83191920000002],"cid":"0xe277e14dbca9f2ab","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"43445"};
        var d = document;
        var s = d.createElement('script');
        s.src = 'https://1map.com/js/script-for-user.js?embed_id=43445';
        s.async = true;
        s.onload = function (e) {
          window.OneMap.initMap(setting)
        };
        var to = d.getElementsByTagName('script')[0];
        to.parentNode.insertBefore(s, to);
      })();</script><a href="https://1map.com/map-embed?embed_id=43445">1map.com</a></div>
            </div>
            <div class="row-md-2 col-sm-2">
              <ul class="bottom-menu-iconic-list">
				<li><a href="http://www.sust.edu" class="fui-sust" target="new">SUST</a></li>
          </ul>
                <li><a href="http://facebook.com/eeesust" class="fui-facebook" target="new"></a></li>
				<li><a href="tel:+8801676524531" class="fui-chat" target="new"></a></li>
              </ul>
          
        </div>